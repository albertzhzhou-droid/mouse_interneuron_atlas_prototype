import assert from "node:assert/strict";
import { readFile } from "node:fs/promises";
import test from "node:test";

const [atlas, lab, viewer, universe] = await Promise.all([
  readFile(new URL("../app/AtlasPrototype.tsx", import.meta.url), "utf8"),
  readFile(new URL("../app/ResearchDataLab.tsx", import.meta.url), "utf8"),
  readFile(new URL("../app/MorphologyViewer.tsx", import.meta.url), "utf8"),
  readFile(new URL("../app/NeuroMorphoUniversePanel.tsx", import.meta.url), "utf8"),
]);

test("profile label discovery drives a shared literal query across both morphology indexes", () => {
  assert.match(atlas, /const literalQuery = sourceLabel\.trim\(\)\.slice\(0, 180\)/);
  assert.match(atlas, /setMorphologySearchQuery\(literalQuery\)/);
  assert.match(atlas, /morphologySearchQuery=\{morphologySearchQuery\}/);
  assert.match(atlas, /onMorphologySearchQueryChange=\{setMorphologySearchQuery\}/);
  assert.match(lab, /morphologySearchQuery=\{morphologySearchQuery\}/);
  assert.match(lab, /onMorphologySearchQueryChange=\{onMorphologySearchQueryChange\}/);
  assert.match(viewer, /morphologySearchQuery=\{morphologySearchQuery\}/);
  assert.match(viewer, /onMorphologySearchQueryChange=\{onMorphologySearchQueryChange\}/);
  assert.ok(universe.includes("Search ID, label, region, DOI, or PMID<input value={query} onChange={(event) => updateSearchQuery(event.target.value)}"));
  assert.ok(viewer.includes("Search ID, label, region or paper\n            <input value={query} onChange={(event) => {"));
  assert.match(viewer, /onMorphologySearchQueryChange\?\.\(event\.target\.value\)/);
});

test("a discovery request clears stale/default geometry and requires explicit exact-record selection", () => {
  assert.match(lab, /key=\{`independent-morphology-discovery-\$\{morphologyDiscoveryRequestId\}`\}/);
  assert.match(viewer, /const explicitDiscoveryMode = morphologyDiscoveryRequestId > 0 \|\| morphologySearchQuery\.trim\(\)\.length > 0/);
  assert.match(viewer, /useState<number \| null>\(\(\) => explicitDiscoveryMode \? null : neuronIdFromInitial\(initialNeuron\)\)/);
  assert.match(viewer, /useState<MorphologyView>\(\(\) => explicitDiscoveryMode \? "universe"/);
  assert.match(viewer, /setInternalSelectedId\(\(current\) => current \?\? \(discoveryModeRef\.current \? null : preferred\?\.neuronId/);
  assert.match(viewer, /const effectiveSelectedId = selectedId \?\? \(explicitDiscoveryMode \? null : filteredRecords\[0\]\?\.neuronId \?\? null\)/);
  assert.match(viewer, /useState<\{ neuronId: number; data: GeometryPayload \} \| null>\(null\)/);
  assert.match(universe, /useState<number \| null>\(\(\) => explicitDiscoveryMode \? null : controlledNeuronId\(selectedFocusId\)\)/);
  assert.match(universe, /explicitDiscoveryRef\.current[\s\S]*\? null[\s\S]*next\.records\.find\(\(record\) => record\.neuronId === 104003\)/);
  assert.match(universe, /useState<GeometryState>\(\{ status: "idle", neuronId: null, geometry: null, error: "" \}\)/);
  assert.match(universe, /if \(!selected\)[\s\S]*setGeometryState\(\{ status: "idle", neuronId: null, geometry: null, error: "" \}\)/);
  assert.match(lab, /No morphology is selected by this search; choose one exact NeuroMorpho record/);
});

test("deep-link restore preserves explicit morphology-browser intent without creating identity", () => {
  assert.match(atlas, /const explicitMorphologyBrowserIntent = requestedLab === "morphology" && morphologyQuery\.trim\(\)\.length > 0/);
  assert.match(atlas, /params\.set\("morphologyQuery", morphologySearchQuery\)/);
  assert.match(atlas, /setMorphologySearchQuery\(locationState\.research\.morphologyQuery\)/);
  assert.match(lab, /literal repository-text search only/);
  assert.match(lab, /It does not establish subtype equivalence or same-cell identity/);
  const handlerStart = atlas.indexOf("const browseIndependentMorphology = useCallback");
  const handlerEnd = atlas.indexOf("\n  }, [setNotice]);", handlerStart);
  const handler = handlerStart < 0 || handlerEnd < 0 ? "" : atlas.slice(handlerStart, handlerEnd);
  assert.ok(handler);
  assert.doesNotMatch(handler, /transitionResearchFocus|selectResearchLab/);
});
