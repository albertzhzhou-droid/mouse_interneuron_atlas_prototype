"use client";

import { useEffect, useState } from "react";
import SourceIdentityHierarchyPanel from "./SourceIdentityHierarchyPanel";
import { SVARA_CATALOGUES, svaraCatalogueEntry, svaraCatalogueIdentity, loadSvaraCataloguePage,
  svaraVerifiedPageBytes, buildSvaraCatalogueReceipt, inspectSvaraCatalogueReceipt,
  restoreSvaraCatalogueReceipt } from "./svara-catalogues.js";
import "./svara-catalogues.css";

type Loaded = { key: string; pngUrl: string; jsonUrl: string; receipt: Record<string, unknown> };

export default function SvaraCatalogueGallery() {
  const [request, setRequest] = useState<{ key: string; revision: number; imported: unknown; refusal: string | null }>({ key: "mmc7:CiD 001", revision: 0, imported: null, refusal: null });
  const [loaded, setLoaded] = useState<Loaded | null>(null);
  const [error, setError] = useState("");
  const [importText, setImportText] = useState("");
  const [importMessage, setImportMessage] = useState("");
  const entry = svaraCatalogueEntry(request.key);
  const catalogue = SVARA_CATALOGUES.catalogues.find(row => row.id === entry.catalogueId)!;
  const entries = SVARA_CATALOGUES.entries.filter(row => row.catalogueId === entry.catalogueId);
  const index = entries.findIndex(row => row.key === request.key);
  const current = loaded?.key === request.key ? loaded : null;

  useEffect(() => {
    const controller = new AbortController();
    const urls: string[] = [];
    if (request.refusal) return () => controller.abort();
    void (async () => {
      try {
        const proof = await loadSvaraCataloguePage(request.key, { signal: controller.signal });
        controller.signal.throwIfAborted();
        if (request.imported !== null) restoreSvaraCatalogueReceipt(request.imported, proof);
        const receipt = buildSvaraCatalogueReceipt(proof, request.key);
        const pngUrl = URL.createObjectURL(new Blob([svaraVerifiedPageBytes(proof, request.key)], { type: "image/png" }));
        const jsonUrl = URL.createObjectURL(new Blob([JSON.stringify(receipt, null, 2) + "\n"], { type: "application/json" }));
        urls.push(pngUrl, jsonUrl);
        setLoaded({ key: request.key, pngUrl, jsonUrl, receipt });
        if (request.imported !== null) setImportMessage("Restored this exact catalogue page after fresh PNG byte verification.");
      } catch (failure) {
        if (!controller.signal.aborted) {
          setError(failure instanceof Error ? failure.message : "Page verification failed.");
          if (request.imported !== null) setImportMessage("Restore refused; no imported page or values were displayed.");
        }
      }
    })();
    return () => { controller.abort(); urls.forEach(url => URL.revokeObjectURL(url)); };
  }, [request]);

  function select(key: string) {
    setLoaded(null); setError(""); setImportMessage("");
    setRequest(previous => ({ key, revision: previous.revision + 1, imported: null, refusal: null }));
  }
  function restore() {
    try {
      if (importText.length > 24000) throw new Error("Receipt exceeds the catalogue page size limit.");
      const imported: unknown = JSON.parse(importText);
      const { key } = inspectSvaraCatalogueReceipt(imported);
      setLoaded(null); setError(""); setImportMessage("Checking fresh source page bytes…");
      setRequest(previous => ({ key, revision: previous.revision + 1, imported, refusal: null }));
    } catch (failure) {
      const refusal = `Restore refused: ${failure instanceof Error ? failure.message : "invalid receipt"}`;
      setLoaded(null); setError(refusal); setImportMessage(refusal);
      setRequest(previous => ({ key: previous.key, revision: previous.revision + 1, imported: null, refusal }));
    }
  }

  return <section id="svara-catalogue-gallery" className="svara-catalogue-gallery" aria-label="Svara original supplementary catalogue pages">
    <h3>Original supplementary catalogues</h3>
    <p>Browse 139 MN, 39 CiD and 34 CoBL publication entries. Labels and reported values remain in their original catalogue. Each image contains the full published page.</p>
    <div className="svara-catalogue-controls">
      <label>Catalogue<select aria-label="Svara catalogue" value={entry.catalogueId} onChange={event => select(SVARA_CATALOGUES.entries.find(row => row.catalogueId === event.target.value)!.key)}>
        {SVARA_CATALOGUES.catalogues.map(row => <option key={row.id} value={row.id}>{row.classLabel} · {row.entryCount} entries · {row.id}</option>)}
      </select></label>
      <label>Original entry<select aria-label="Svara original entry" value={request.key} onChange={event => select(event.target.value)}>
        {entries.map(row => <option key={row.key} value={row.key}>{row.sourceHeader}</option>)}
      </select></label>
      <button type="button" disabled={index === 0} onClick={() => select(entries[index - 1].key)}>Previous entry</button>
      <button type="button" disabled={index === entries.length - 1} onClick={() => select(entries[index + 1].key)}>Next entry</button>
    </div>
    <p role="status" aria-live="polite" data-testid="svara-page-status">{error || (current ? `${entry.sourceLabel} · page ${entry.sourcePage}/${catalogue.entryCount} · current PNG bytes verified` : "Verifying this original page image…")}</p>
    {error && <button type="button" onClick={() => select(request.key)}>Retry page verification</button>}
    {current && <>
      <figure>
        {/* The Blob contains privately verified bytes, never an unverified source URL. */}
        {/* eslint-disable-next-line @next/next/no-img-element */}
        <img src={current.pngUrl} alt={`Complete original ${entry.sourceHeader} publication page, ${entry.sourcePdfMember}, page ${entry.sourcePage}`} width={entry.raster.widthPixels} height={entry.raster.heightPixels} data-testid="svara-source-page" />
        <figcaption>{entry.sourceHeader} · {entry.sourcePdfMember}, page {entry.sourcePage}. Svara et al. (2018), CC BY 4.0. PDF page rendered at 96 dpi; diagrams unchanged.</figcaption>
      </figure>
      <h4>Values reported on this source page</h4>
      <p>These strings come from the published table. No measurements were calculated from the image.</p>
      <dl className="svara-catalogue-fields" data-testid="svara-reported-fields">{entry.reportedFields.map(field => <div key={field.label}><dt>{field.label}</dt><dd>{field.sourceText}</dd></div>)}</dl>
      <nav className="svara-catalogue-downloads" aria-label="Verified Svara page downloads">
        <a href={current.pngUrl} download={`svara-${entry.catalogueId}-page-${entry.sourcePage}.png`}>Download original page PNG</a>
        <a href={current.jsonUrl} download={`svara-${entry.catalogueId}-page-${entry.sourcePage}-source.json`}>Download page source receipt</a>
      </nav>
      <p className="svara-catalogue-proof">Only this {entry.raster.bytes.toLocaleString()}-byte PNG is fetched and checked here. Full ZIP and PDF hashes were checked during extraction. The receipt includes attribution, original component, page, reported values and this distinction.</p>
      <SourceIdentityHierarchyPanel hierarchy={svaraCatalogueIdentity(request.key)} />
      <details><summary>Extracted original page text and source receipt</summary><pre data-testid="svara-page-text">{entry.sourcePageText}</pre><pre data-testid="svara-page-receipt">{JSON.stringify(current.receipt, null, 2)}</pre></details>
    </>}
    <details className="svara-catalogue-restore"><summary>Restore a downloaded page receipt</summary>
      <label>Page source receipt JSON<textarea aria-label="Svara page source receipt JSON" value={importText} onChange={event => setImportText(event.target.value)} rows={6} maxLength={24001} /></label>
      <button type="button" onClick={restore}>Restore exact catalogue page</button><p role="status" aria-live="polite" data-testid="svara-restore-status">{importMessage}</p>
    </details>
    <p className="svara-catalogue-boundary">The available files contain published two dimensional views. They provide no editable skeleton, mesh, raw volume or endpoint table. Physical cell/section IDs, coordinate frames and the exact Koh annotation version remain unestablished. CiD is a morphological source label; no genetic V2a assignment or mouse registration is made.</p>
    <p>{SVARA_CATALOGUES.citation} <a href="https://doi.org/10.1016/j.celrep.2018.05.023" target="_blank" rel="noreferrer">Article ↗</a>{" · "}<a href={SVARA_CATALOGUES.rights.licenseUrl} target="_blank" rel="noreferrer">CC BY 4.0 ↗</a></p>
    <p>Reuse basis: the exact article&apos;s license and the publisher&apos;s explicit policy for its supplementary data. The ZIP metadata has no separate license field. <a href={SVARA_CATALOGUES.rights.publisherPolicyUrl} target="_blank" rel="noreferrer">Publisher policy ↗</a></p>
  </section>;
}
