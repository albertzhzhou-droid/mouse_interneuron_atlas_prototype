import { svaraLarvalZebrafishSpinalSbemReference } from "./atlas-types";

export default function SvaraLarvalZebrafishSpinalSbemReference() {
  const reference = svaraLarvalZebrafishSpinalSbemReference;
  const scope = reference.biologicalScope;
  const acquisition = reference.acquisition;
  const coverage = acquisition.segmentCoverage;
  const reconstructions = reference.publishedReconstructions;
  const supplements = reference.supplementPackages;
  const boundary = reference.identityAndGeometryBoundary;

  return (
    <details className="svara-sbem-reference-card">
      <summary>
        <div><span>UPG-240 · COMPARATIVE SPINAL SBEM · LARVAL ZEBRAFISH</span><strong>Source-reported CiD / CoBL circuit · not mouse-cell geometry</strong></div>
        <em>LINKS ONLY · 0 ADMITTED OBJECTS</em>
      </summary>
      <p>{scope.species} · {scope.lifeStage} · one larva · {acquisition.modality}. The source volume is {acquisition.reportedVolumeLengthMicrometre.join(" × ")} μm at a reported {acquisition.reportedVoxelPitchNanometre.join(" × ")} nm voxel pitch. It contains {coverage.fullyContainedSegments} complete segments, {coverage.adjacentSegmentCoveragePercent[0].coveragePercent}% of the rostral and {coverage.adjacentSegmentCoveragePercent[1].coveragePercent}% of the caudal adjoining segment, and {coverage.somataInVolume.toLocaleString()} somata.</p>
      <ul aria-label="Source-reported reconstruction counts">
        <li>{reconstructions.motoneurons.count} motoneurons · {reconstructions.motoneurons.leftHemisegment} left / {reconstructions.motoneurons.rightHemisegment} right</li>
        <li>{reconstructions.morphologyConsistentCiDs.count} cells with morphology consistent with CiD among {reconstructions.morphologyConsistentCiDs.completelyTracedCellContext} completely traced cells</li>
        <li>{reconstructions.CoBLs.count} source-reported CoBL reconstructions</li>
      </ul>
      <div className="svara-sbem-boundary" role="note">
        <strong>UPG-240 · Official archive routes listed; object-level reconstruction not yet verified</strong>
        <p>The official record lists {supplements.reportedPackageCount} ZIP packages ({supplements.packages.map((item) => item.filename).join(", ")}). Their internal files, byte sizes, checksums, stable neuron IDs, coordinate fields, reconstruction completeness and per-package reuse terms remain unknown. {boundary.appAdmittedSkeletons} skeletons, {boundary.appAdmittedMeshes} meshes and {boundary.appAdmittedSynapseEdges} synapse edges are admitted. Zebrafish identities or coordinates are not transferred to mouse records.</p>
        <span>The article describes the morphological CiD set as consistent with V2a-type cells; this is not a genetic V2a assignment. The CC BY 4.0 statement is verified for the article, not independently for each supplementary archive.</span>
      </div>
      <p className="svara-sbem-next-gate"><strong>UPG-250 · Next morphology gate:</strong> verify archive members, stable neuron IDs, coordinate frame, trace completeness, hashes and file-specific reuse terms before any source-local reconstruction is admitted.</p>
      <nav className="svara-sbem-package-links" aria-label="Official Svara supplementary ZIP package links">
        {supplements.packages.map((item, index) => (
          <a key={item.repositoryComponentId} href={item.sourceUrl} target="_blank" rel="noreferrer" data-testid={`svara-package-${index + 6}`}>
            Official archive · mmc{index + 6} ZIP ↗
          </a>
        ))}
      </nav>
      <nav aria-label="Svara comparative spinal SBEM source links">
        {reference.sources.slice(0, 3).map((source) => <a key={source.url} href={source.url} target="_blank" rel="noreferrer">{source.label} ↗</a>)}
      </nav>
    </details>
  );
}
