"use client";

import { useState } from "react";
import type { MorphologySourceViewDocument, IndividualMorphologySourceViewDocument } from "./morphology-source-view.js";
import type { MainSceneSourceViewDocument } from "./main-scene-source-view.js";
import "./morphology-source-view.css";

export default function MorphologySourceViewControls({ neuronId, signature, available, restoring, capture, restore, description, unavailableReason }: {
  neuronId: number; signature: string; available: boolean; restoring: boolean;
  capture: () => MorphologySourceViewDocument | IndividualMorphologySourceViewDocument | MainSceneSourceViewDocument;
  restore: (document: unknown) => Promise<void>;
  description?: string; unavailableReason?: string;
}) {
  const [prepared, setPrepared] = useState<{ signature: string; document: MorphologySourceViewDocument | IndividualMorphologySourceViewDocument | MainSceneSourceViewDocument } | null>(null);
  const [input, setInput] = useState("");
  const [message, setMessage] = useState("");
  const current = available && prepared?.signature === signature ? prepared.document : null;
  const prepare = () => {
    try { setPrepared({ signature, document: capture() }); setMessage("Current source view captured. Changes to the view clear this capture."); }
    catch (error) { setPrepared(null); setMessage(error instanceof Error ? error.message : "The current view is unavailable."); }
  };
  const download = () => {
    if (!current) return;
    const url = URL.createObjectURL(new Blob([JSON.stringify(current, null, 2)], { type: "application/json" }));
    const link = document.createElement("a");
    link.href = url; link.download = `neuromorpho-${neuronId}-source-view.json`; link.click();
    setTimeout(() => URL.revokeObjectURL(url), 1000);
  };
  const replay = async () => {
    try {
      const document = JSON.parse(input);
      setPrepared(null); setMessage("Rechecking the exact source file before restoring the view…");
      await restore(document);
      setMessage("Source file rechecked and view restored. Capture again to record the new verification and viewport.");
    } catch (error) { setMessage(error instanceof Error ? error.message : "The source view could not be restored."); }
  };
  return <details className="morphology-source-view-controls" aria-label={`Source view receipt for NeuroMorpho ${neuronId}`}>
    <summary>Save or restore this source view</summary>
    <p>{description ?? "Save this camera, topology layer and branch selection. Restoration rechecks the exact source file and adapts to the current viewport size. Source axes remain local; no atlas registration or internal anatomy is added."}</p>
    {!available && !restoring && unavailableReason && <p role="status">{unavailableReason}</p>}
    <div className="morphology-source-view-actions">
      <button type="button" disabled={!available || restoring} onClick={prepare}>Capture source view</button>
      <button type="button" disabled={!current || restoring} onClick={download}>Export source view JSON</button>
    </div>
    {current && <textarea readOnly aria-label={`Current source view receipt for NeuroMorpho ${neuronId}`} value={JSON.stringify(current, null, 2)} rows={7} />}
    <label>Paste a saved view for this source
      <textarea aria-label={`Saved source view for NeuroMorpho ${neuronId}`} value={input} onChange={event => setInput(event.target.value)} rows={5} disabled={restoring} />
    </label>
    <button type="button" disabled={!input.trim() || restoring} onClick={() => { void replay(); }}>Restore source view</button>
    {message && <p role="status">{message}</p>}
  </details>;
}
