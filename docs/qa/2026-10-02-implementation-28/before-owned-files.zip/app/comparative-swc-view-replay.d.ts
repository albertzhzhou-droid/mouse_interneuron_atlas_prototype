import type { ComparativeIndex, ComparativeObject, ComparativePayload } from "./comparative-swc-reference.js";
import type { IndependentViewState } from "./independent-source-workspace-types";
import type { SourceIdentityHierarchy, SourceRelationship } from "./source-object-identity.js";
export type ComparativeViewDocument = { documentType: string; schemaVersion: string; applicationVersion: string; object: Record<string, unknown>; verification: Record<string, unknown>; view: IndependentViewState; sourceIdentity: SourceIdentityHierarchy; comparativeContractId: string; scientificScope: Record<string, unknown>; scope: string };
export function comparativeSourceIdentityHierarchy(index: ComparativeIndex, key: string): SourceIdentityHierarchy;
export function comparativeSourceCoDisplayRelationship(index: ComparativeIndex): SourceRelationship;
export function exportComparativeSwcView(index: ComparativeIndex, key: string, payload: ComparativePayload, view: IndependentViewState, applicationVersion: string, verificationRevision: number): ComparativeViewDocument;
export function validateComparativeSwcViewReplay(index: ComparativeIndex, document: unknown, payload: ComparativePayload, applicationVersion: string, currentRendererVersion?: string | null): { record: ComparativeObject; view: IndependentViewState };
