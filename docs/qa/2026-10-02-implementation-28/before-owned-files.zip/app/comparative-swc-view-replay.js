import { createComparativeSwcReferenceIndex, findComparativeSwcReference } from "./comparative-swc-reference.js";
import { exportIndependentSourceObject } from "./independent-source-objects.js";
import { independentSourceReplayExport, validateIndependentSourceViewReplay } from "./independent-source-workspace-state.js";
import { independentSourceIdentityHierarchy, resolveSourceRelationship } from "./source-object-identity.js";
const same = (left, right) => JSON.stringify(left) === JSON.stringify(right);
function check(condition, message) { if (!condition) throw new Error(`Comparative view replay: ${message}`); }
function sourceIndex(index) {
  // Revalidate the complete pinned source contract before using shared view/identity rules.
  createComparativeSwcReferenceIndex({ documentType: "independent_comparative_swc_reference", ...index, sourceLocalCoordinatePolicy: index.coordinatePolicy });
  return { contractId: index.contractId, sources: [], fixedRecords: index.objects, collections: [] };
}
function currentPayload(object, payload) {
  check(payload?.key === object?.key && payload.kind === "comparative_swc" && payload.receipt?.status === "verified" && payload.receipt.objectKey === object.key, "the exact current source loader receipt is required");
  check(payload.receipt.sourceId === object.sourceId && payload.receipt.releaseId === object.releaseId && payload.receipt.sourceObjectId === object.sourceObjectId && same(payload.receipt.coordinateFrame, object.coordinateFrame), "source/version/frame differs from the current loader");
  check(payload.receipt.verifiedFiles?.length === object.files.length && object.files.every((file) => payload.receipt.verifiedFiles.filter((receipt) => receipt.fileId === file.id && receipt.path === file.path && receipt.bytes === file.bytes && same(receipt.checksum, file.checksum) && receipt.status === "verified").length === 1), "current loader asset receipts are incomplete");
}
export function comparativeSourceIdentityHierarchy(index, key) {
  return independentSourceIdentityHierarchy(sourceIndex(index), key);
}
export function comparativeSourceCoDisplayRelationship(index) {
  const current = sourceIndex(index);
  return resolveSourceRelationship(independentSourceIdentityHierarchy(current, index.objects[0].key), independentSourceIdentityHierarchy(current, index.objects[1].key));
}
export function exportComparativeSwcView(index, objectKey, payload, view, applicationVersion, verificationRevision) {
  const current = sourceIndex(index), object = findComparativeSwcReference(index, objectKey);
  check(object && view?.status === "rendered" && view.verificationRevision === verificationRevision, "capture requires the current verified/rendered generation");
  currentPayload(object, payload);
  const document = { ...independentSourceReplayExport(object, payload, view, applicationVersion, current), comparativeContractId: index.contractId, scientificScope: index.scope };
  validateComparativeSwcViewReplay(index, document, payload, applicationVersion, view.renderer?.version ?? null);
  return document;
}
export function validateComparativeSwcViewReplay(index, document, payload, applicationVersion, currentRendererVersion = null) {
  const current = sourceIndex(index), object = findComparativeSwcReference(index, document?.object?.key);
  check(object, "source object/release is unavailable; no substitute selected");
  currentPayload(object, payload);
  check(document.comparativeContractId === index.contractId && same(document.scientificScope, index.scope), "scientific scope differs from the pinned comparative contract");
  check(same(document.object, exportIndependentSourceObject(object).object) && same(document.verification, payload.receipt), "saved source evidence differs from the current checksum-verified loader receipt");
  check(document.sourceIdentity && same(document.sourceIdentity, comparativeSourceIdentityHierarchy(index, object.key)), "saved reconstruction hierarchy changed its namespace, parent or missingness");
  const result = validateIndependentSourceViewReplay(current, document, applicationVersion);
  const view = result.view;
  check(view.status === "rendered", "a replayable comparative view requires an actual rendered camera; text evidence remains a separate export");
  check(view.clipping && same(view.clipping, { globalPlanes: [], localClippingEnabled: false }), "saved view lacks the actual renderer clipping state");
  check(Number.isSafeInteger(view.verificationRevision) && view.verificationRevision > 0 && typeof view.revision === "string" && view.revision.trim(), "saved view has no actual renderer generation");
  check([view.loadMilliseconds, view.renderMilliseconds].every((value) => Number.isFinite(value) && value >= 0), "saved verification/render timing is invalid");
  if (view.status === "rendered") {
    const bounds = object.context.computedFromExactSwc.boundsMicrometre;
    const expected = { centerNative: bounds.min.map((value, axis) => (value + bounds.max[axis]) / 2), scale: 200 / Math.max(...object.context.computedFromExactSwc.extentMicrometre), coordinateFrame: object.coordinateFrame };
    check(same(view.displayTransform, expected), "saved display transform differs from exact source geometry bounds");
    const delta = view.camera.position.map((value, axis) => value - view.camera.target[axis]), up = view.camera.up;
    const cross = [delta[1] * up[2] - delta[2] * up[1], delta[2] * up[0] - delta[0] * up[2], delta[0] * up[1] - delta[1] * up[0]];
    check(Math.hypot(...delta) > Number.EPSILON && Math.hypot(...up) > Number.EPSILON && Math.hypot(...cross) > Number.EPSILON, "saved camera basis is degenerate");
    check(currentRendererVersion === null || view.renderer.version === currentRendererVersion, "saved renderer version differs from the currently rendered build");
  }
  return { record: object, view };
}
