import { readFile, writeFile } from "node:fs/promises";
import path from "node:path";
import { fileURLToPath } from "node:url";

export const RUNTIME_RENDERER_INPUT_TRANSPORT_PATH = "data/research-renderer-runtime-inputs-2.91.json";
// This recipe covers the exact declared build inputs and auxiliary source assets.
// New viewer dependencies must update the recipe; coverage tests fail on omissions.
export const RUNTIME_RENDERER_INPUT_PATHS = Object.freeze([
  "app/AtlasPrototype.tsx",
  "app/ComparativeSwcReferenceWorkbench.tsx",
  "app/IndependentSourceObjectViewport.tsx",
  "app/IndependentSourceObjectWorkspace.tsx",
  "app/MorphologyNeuriteInspector.tsx",
  "app/MorphologySourceViewControls.tsx",
  "app/MorphologyViewer.tsx",
  "app/NativeContourDiagnostics.tsx",
  "app/NativeContourDiagnosticsDisclosure.tsx",
  "app/NativeContourRecordViewer.tsx",
  "app/NeuroMorphoUniversePanel.tsx",
  "app/SceneCanvas.tsx",
  "app/SourceIdentityHierarchyPanel.tsx",
  "app/SourceLocalMorphologyViewport.tsx",
  "app/atlas-reference-geometry.js",
  "app/atlas-types.ts",
  "app/banc-v888-in14a018-morphology-route.js",
  "app/comparative-swc-png-export.d.ts",
  "app/comparative-swc-png-export.js",
  "app/comparative-swc-reference.css",
  "app/comparative-swc-reference.d.ts",
  "app/comparative-swc-reference.js",
  "app/comparative-swc-view-replay.d.ts",
  "app/comparative-swc-view-replay.js",
  "app/globals.css",
  "app/independent-source-object-loader.d.ts",
  "app/independent-source-object-loader.js",
  "app/independent-source-object-png.d.ts",
  "app/independent-source-object-png.js",
  "app/independent-source-object-view.d.ts",
  "app/independent-source-object-view.js",
  "app/independent-source-objects.js",
  "app/independent-source-workspace-state.js",
  "app/independent-source-workspace-types.ts",
  "app/independent-source-workspace.css",
  "app/janelia-wt-bounded-reference-viewer.module.css",
  "app/janelia-wt-bounded-reference-viewer.tsx",
  "app/janelia-wt-bounded-reference.js",
  "app/janelia-wt-source-view.d.ts",
  "app/janelia-wt-source-view.js",
  "app/main-scene-auxiliary-verification.js",
  "app/main-scene-export.js",
  "app/main-scene-morphology-verification.js",
  "app/main-scene-source-view.js",
  "app/main-scene-state-import.js",
  "app/microns-source-native-clipping.js",
  "app/morphology-census-data.ts",
  "app/morphology-geometry-verification.js",
  "app/morphology-neurite-inspection.js",
  "app/morphology-neurite-inspector.css",
  "app/morphology-png-export.js",
  "app/morphology-render-mode.js",
  "app/morphology-source-frame-runtime.js",
  "app/morphology-source-identity.js",
  "app/morphology-source-proof.css",
  "app/morphology-source-view.css",
  "app/morphology-source-view.js",
  "app/morphology-viewport-scale.js",
  "app/native-contour-derived-soma-surface.js",
  "app/native-contour-detail.css",
  "app/native-contour-diagnostics.css",
  "app/native-contour-diagnostics.d.ts",
  "app/native-contour-diagnostics.js",
  "app/native-contour-png-export.js",
  "app/native-contour-source-view.js",
  "app/native-contour-verification.js",
  "app/native-dat-manifest-transport.js",
  "app/neurolucida-dat-file-admission.js",
  "app/neurolucida-dat-inventory.js",
  "app/neurolucida-dat-swc-crosswalk.js",
  "app/neurolucida-native-contour-admission.js",
  "app/neurolucida-native-detail-admission.js",
  "app/neurolucida-native-detail-records.js",
  "app/neurolucida-native-soma-contours.js",
  "app/neuromorpho-swc-runtime.js",
  "app/neuromorpho-universe-verification.js",
  "app/neuromorpho-universe-view.css",
  "app/source-identity-hierarchy.css",
  "app/source-list-keyboard.css",
  "app/source-list-roving-focus.d.ts",
  "app/source-list-roving-focus.js",
  "app/source-local-morphology-geometry.js",
  "app/source-object-identity.d.ts",
  "app/source-object-identity.js",
  "app/source-view-png-raster.d.ts",
  "app/source-view-png-raster.js",
  "app/useSourceListRovingFocus.ts",
  "data/banc-v888-candidate-audit-0.1.json",
  "data/banc-v888-in14a018-morphology-route-0.1.json",
  "data/comparative-swc-reference-0.1.json",
  "data/janelia-wt-bounded-reference-0.1.json",
  "data/microns-observed-cell-nucleus-reference-0.1.json",
  "data/microns-source-native-clipping-0.1.json",
  "data/microstructformer-ultrastructure-reference-0.1.json",
  "data/native-contour-derived-soma-surface-0.1.json",
  "data/native-contour-source-context-0.1.json",
  "data/native-dat-manifest-transport-0.1.json",
  "data/neurolucida-dat-file-manifest-0.1.json",
  "data/neurolucida-dat-swc-crosswalk-0.1.json",
  "data/neurolucida-native-contour-admission-catalog-0.3.json",
  "data/neurolucida-native-contour-admission-catalog-0.4.json",
  "data/neuromorpho-census-main-scene-index-0.1.json",
  "data/neuromorpho-no-age-query-universe-0.1.json",
  "data/neuromorpho-no-age-query-universe-roster-0.1.json",
  "data/neuromorpho-release-8-6-126-todd-nts-route-pack-0.1.json",
  "data/super-clem-palm-localization-reference-0.1.json",
  "package-lock.json",
  "package.json",
  "public/data/allen_cord_20um_v3_0/atlas-contours.json",
  "public/data/allen_cord_20um_v3_0/atlas-internal-compartments.json",
  "public/data/banc_v888_in14a018_comparative_v1/720575941350424112_skeleton.swc",
  "public/data/comparative_swc_reference_v1/nmo-183779-api.json",
  "public/data/comparative_swc_reference_v1/nmo-183779-morphometry.json",
  "public/data/comparative_swc_reference_v1/nmo-183779.swc",
  "public/data/comparative_swc_reference_v1/nmo-34024-api.json",
  "public/data/comparative_swc_reference_v1/nmo-34024-morphometry.json",
  "public/data/comparative_swc_reference_v1/nmo-34024.swc",
  "public/data/functional_class_observed_morphology_route_pack_v1/native-contours/nmo-45674-source-closed-soma-contours.json",
  "public/data/functional_class_observed_morphology_route_pack_v1/native-contours/nmo-50424-mbf-cell-body-line-loops.json",
  "public/data/janelia_wt_reference_v1/nucleus.u8",
  "public/data/janelia_wt_reference_v1/raw.u8",
  "public/data/microns_phase1_v185_4_root_648518346349516051_v1/asset-manifest.json",
  "public/data/microns_phase1_v185_4_root_648518346349516051_v1/browser/cell.positions.f32le.bin",
  "public/data/microns_phase1_v185_4_root_648518346349516051_v1/browser/cell.triangles.u32le.bin",
  "public/data/microns_phase1_v185_4_root_648518346349516051_v1/browser/nucleus.positions.f32le.bin",
  "public/data/microns_phase1_v185_4_root_648518346349516051_v1/browser/nucleus.triangles.u32le.bin",
  "public/data/microns_phase1_v185_4_root_648518346349516051_v1/source/metadata/soma_valence_v185.csv",
  "public/data/native_contour_derived_soma_surface_v1/nmo-50394-cell-body-interpolated-open-shell-0.1.json",
  "public/data/native_dat_file_manifests_v1/nmo-108978.json",
  "public/data/native_dat_file_manifests_v1/nmo-249676.json",
  "public/data/native_dat_file_manifests_v1/nmo-45674.json",
  "public/data/native_dat_file_manifests_v1/nmo-45718.json",
  "public/data/native_dat_file_manifests_v1/nmo-50394.json",
  "public/data/native_dat_file_manifests_v1/nmo-50408.json",
  "public/data/native_dat_file_manifests_v1/nmo-50424.json",
  "public/data/neurolucida_native_detail_v1/nmo-108978-soma-line-loops.json",
  "public/data/neurolucida_native_detail_v1/nmo-249676-soma-line-loops.json",
  "public/data/premotor_comparison_observed_morphology_route_pack_v1/geometry/nmo-45718.json",
  "public/data/premotor_comparison_observed_morphology_route_pack_v1/native-contours/nmo-45718-soma-contours.json",
  "public/data/prp_dorsal_horn_observed_morphology_route_pack_v1/native-contours/nmo-50394-mbf-cell-body-line-loops.json",
  "public/data/prp_dorsal_horn_observed_morphology_route_pack_v1/native-contours/nmo-50408-mbf-cell-body-line-loops.json",
  "public/data/superclem_palm_native_points_0_1.json"
]);
const check = (ok, message) => { if (!ok) throw new Error(`Renderer runtime inputs: ${message}`); };
export function buildRendererRuntimeInputs(authoritativeInputs) {
  check(Array.isArray(authoritativeInputs), "canonical inputs are missing");
  const rows = RUNTIME_RENDERER_INPUT_PATHS.map(relative => {
    const matching = authoritativeInputs.filter(row => row.path === relative);
    check(matching.length === 1, `canonical input is missing or duplicated: ${relative}`);
    const row = matching[0];
    check(Number.isSafeInteger(row.bytes) && row.bytes > 0 && /^[a-f0-9]{64}$/.test(row.sha256), `canonical byte pin is invalid: ${relative}`);
    return { path: row.path, bytes: row.bytes, sha256: row.sha256 };
  });
  return { schemaVersion: "0.1.0", applicationVersion: "2.91.0-research.1", scope: "exact_current_renderer_and_auxiliary_input_pins", authoritativeInputs: rows };
}
export function rendererRuntimeInputsBytes(authoritativeInputs) {
  return Buffer.from(JSON.stringify(buildRendererRuntimeInputs(authoritativeInputs), null, 2) + "\n");
}
export function validateRendererRuntimeInputs(actual, authoritativeInputs) {
  check(JSON.stringify(actual) === JSON.stringify(buildRendererRuntimeInputs(authoritativeInputs)), "transport differs from exact canonical runtime pins");
  return { inputCount: actual.authoritativeInputs.length, canonicalPinsUnchanged: true, scientificSourceAdmissionChanged: false };
}
const root = fileURLToPath(new URL("../", import.meta.url));
if (process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  const manifest = JSON.parse(await readFile(path.join(root, "data/research-iteration-manifest-2.91.json"), "utf8"));
  const bytes = rendererRuntimeInputsBytes(manifest.authoritativeInputs);
  if (process.argv.includes("--write")) await writeFile(path.join(root, RUNTIME_RENDERER_INPUT_TRANSPORT_PATH), bytes);
  const actual = await readFile(path.join(root, RUNTIME_RENDERER_INPUT_TRANSPORT_PATH));
  check(actual.equals(bytes), "transport is stale; regenerate together with the current manifest");
  console.log(JSON.stringify(validateRendererRuntimeInputs(JSON.parse(actual), manifest.authoritativeInputs)));
}
