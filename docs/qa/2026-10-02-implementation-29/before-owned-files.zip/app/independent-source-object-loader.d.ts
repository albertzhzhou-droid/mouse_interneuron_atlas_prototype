import type { IndependentObject, IndependentPayload } from "./independent-source-workspace-types";

export type VerifiedAssetReceipt = { fileId: string; path: string; bytes: number; checksum: { algorithm: "SHA-256"; digest: string }; status: "verified" };
export function verifyIndependentSourceObjectAsset(bytes: ArrayBuffer, receipt: { id: string; path: string; bytes: number; checksum: { algorithm: string; digest: string } }, options?: { digestImpl?: SubtleCrypto }): Promise<VerifiedAssetReceipt>;
export function loadIndependentSourceObject(object: IndependentObject, options?: {
  fetchImpl?: typeof fetch; signal?: AbortSignal; includeDerivedShell?: boolean;
}): Promise<IndependentPayload>;
