import AtlasPrototype, { type InitialAtlasParams } from "../AtlasPrototype";
export default async function WorkspacePage({ searchParams }: { searchParams: Promise<InitialAtlasParams> }) {
  return <AtlasPrototype initialParams={await searchParams} />;
}
