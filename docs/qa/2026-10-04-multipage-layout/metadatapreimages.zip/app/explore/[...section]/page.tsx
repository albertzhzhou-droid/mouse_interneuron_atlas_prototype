import ResearchRoutePage from "../../ResearchRoutePage";
export default async function ExplorePage({ params, searchParams }: { params: Promise<{ section: string[] }>; searchParams: Promise<Record<string, string | string[] | undefined>> }) {
  const { section } = await params;
  return <ResearchRoutePage path={`/explore/${section.join("/")}`} initialParams={await searchParams} />;
}
