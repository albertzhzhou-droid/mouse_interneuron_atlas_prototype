"use client";

import { useId, useMemo, useState } from "react";
import coordinateAudit from "../data/bil-xenium-coordinate-source-audit-0.1.json";
import { validateBilXeniumCoordinateSourceAudit } from "./bil-xenium-coordinate-source-audit.js";
import audit from "../data/bil-xenium-geometry-schema-audit-0.1.json";
import metadata from "../data/bil-xenium-source-metadata-0.1.json";
import { buildBilXeniumAuditedCellHierarchy, validateBilXeniumGeometrySchemaAudit } from "./bil-xenium-geometry-schema-audit.js";
import SourceIdentityHierarchyPanel from "./SourceIdentityHierarchyPanel";
import styles from "./bil-xenium-metadata-explorer.module.css";

export default function BilXeniumGeometrySchemaAudit({ sourceObjectKey, onSelectAcquiredRun }: { sourceObjectKey: string; onSelectAcquiredRun: () => void }) {
  const id = useId();
  const [sampleId, setSampleId] = useState(audit.tables.cells.sampleRows[0].cellId);
  const validation = useMemo(() => {
    try { validateBilXeniumGeometrySchemaAudit(audit, metadata); validateBilXeniumCoordinateSourceAudit(coordinateAudit, audit); return null; }
    catch (error) { return error instanceof Error ? error.message : "Source-table audit validation failed"; }
  }, []);
  if (validation) return <p role="alert">{validation}</p>;
  const acquired = sourceObjectKey === audit.sourceObjectKey;
  const cells = audit.tables.cells, boundaries = audit.tables.cellBoundaries, nuclei = audit.tables.nucleusBoundaries;
  const sample = acquired ? cells.sampleRows.find((row) => row.cellId === sampleId) : null;
  const hierarchy = sample ? buildBilXeniumAuditedCellHierarchy(audit, metadata, sample.cellId) : null;

  return <details className={styles.schemaAudit} data-testid="bil-xenium-geometry-schema-audit" data-current-source-key={sourceObjectKey}>
    <summary>Source table audit · {acquired ? "cell and nucleus IDs inspected" : "one other run inspected"}</summary>
    {!acquired ? <div className={styles.auditBody}>
      <p>No original cell or boundary table has been inspected for the selected run. A bounded three-table audit is available for {audit.directoryFolder}.</p>
      <button type="button" className={styles.auditButton} onClick={onSelectAcquiredRun}>Open the inspected run</button>
    </div> : <div className={styles.auditBody} data-testid="bil-xenium-current-schema-audit">
      <p>{cells.rowCount.toLocaleString()} source segmentation rows and three original Parquet tables ({(audit.totalSourceBytes / 1_000_000).toFixed(2)} MB) were inspected. This is one processing ROI; its cells have no verified section, donor or curated type assignment in these inputs.</p>
      <dl className={styles.facts}>
        <div><dt>Cell table IDs / duplicate IDs</dt><dd>{cells.uniqueCellIdCount.toLocaleString()} / {cells.duplicateCellIdCount}</dd></div>
        <div><dt>Cell boundary IDs / vertex rows</dt><dd>{boundaries.uniqueCellIdCount.toLocaleString()} / {boundaries.rowCount.toLocaleString()}</dd></div>
        <div><dt>IDs with nucleus boundaries / nucleus polygons</dt><dd>{nuclei.uniqueCellIdCount.toLocaleString()} / {nuclei.polygonGroupCount.toLocaleString()}</dd></div>
        <div><dt>No detected nucleus / multiple detected nuclei</dt><dd>{cells.nucleusCountDistribution["0"].toLocaleString()} / {nuclei.cellsWithMultiplePolygonGroups}</dd></div>
      </dl>
      <p className={styles.notice}>Join the three files by exact cell_id within this analysis and ROI. {audit.idJoins.crossFileLabelIdDifferentCellCount.toLocaleString()} shared numeric label IDs point to different cells across the two boundary files. Polygon vertices are repeated observations, and multiple nucleus polygons can belong to one cell.</p>
      <p>All cell IDs have a cell boundary; no boundary ID is orphaned. The {audit.idJoins.cellTableIdsWithoutNucleusBoundary.toLocaleString()} IDs without a nucleus boundary match source nucleus_count = 0. Per-cell nucleus counts agree with the number of nucleus polygons, including all 62 multi-nucleus records.</p>
      <p className={styles.notice}>The {audit.methodCrosscheck.tableCounts.nuc_expansion.toLocaleString()} rows with the native label “{audit.methodCrosscheck.distanceEvidence.nativeValue}” explicitly report 5.0 µm. This applies to those rows in this run. The other two methods use source stain segmentation.</p>
      <details data-testid="bil-xenium-current-coordinate-evidence"><summary>Original coordinate evidence · 182,698 exact cell IDs</summary>
        <p>The original cells.zarr.zip metadata for this run declares “microns”. Every cell ID joins the original cells.parquet, and all X/Y centroids, cell areas, nucleus areas and nucleus counts are exactly equal. The 2,262 missing nucleus areas remain source NaN.</p>
        <dl className={styles.facts}><div><dt>Cell centroid coordinates</dt><dd>µm · original archive declaration</dd></div><div><dt>Exact ID joins / different centroid values</dt><dd>182,698 / 0</dd></div><div><dt>Archive entry version</dt><dd>6.2 · XOA 3.3.0.1 run</dd></div><div><dt>Coordinate evidence scope</dt><dd>Cell centroids · no section or atlas transform</dd></div></dl>
        <p>The stored physical-to-image matrix has X/Y scale 4.7058820724487305, with the run’s pixel_size 0.2125. The matrix is retained at its original float32 precision; it does not map named outlines to cells or establish anatomical orientation. The Parquet files themselves contain no unit metadata, and their polygon coordinates have not been compared with Zarr polygon arrays.</p>
        <p>Only selected archive entries were acquired and replayed from exact byte ranges with ZIP CRC checks. Unread masks, polygons and the whole 252 MB archive are not claimed verified.</p>
        <p>Ten automatic clusterings assign 182,490 cells and leave 208 unassigned. Their “Cluster” names are algorithm groups, with no curated interneuron labels. The 609 fields of view in each source location file do not establish sections.</p>
        <p className={styles.notice}>Section, per-section donor, curated types and the separate rights declarations remain unresolved. This coordinate evidence adds 0 viewer geometry, 0 3D cells, 0 identity joins and 0 REG.</p>
      </details>
      <div className={styles.controls}>
        <label htmlFor={`${id}-row`}>Inspect a pinned source row
          <select id={`${id}-row`} value={sampleId} onChange={(event) => setSampleId(event.target.value)}>
            {cells.sampleRows.map((row) => <option key={row.cellId} value={row.cellId}>{row.cellId} · row {row.rowIndexZeroBased} · nucleus count {row.fields.nucleus_count.value}</option>)}
          </select>
        </label>
      </div>
      {sample ? <div key={sample.cellId} data-testid="bil-xenium-audited-source-row" data-cell-id={sample.cellId}>
        <p><strong>{sample.cellId}</strong> · cells.parquet · zero-based row {sample.rowIndexZeroBased}. Four pinned examples illustrate source fields; this is not the full cell roster.</p>
        <table className={styles.table} aria-label="Pinned Xenium source row fields"><thead><tr><th>Source column</th><th>Source value</th></tr></thead>
          <tbody>{Object.entries(sample.fields).map(([name, field]) => <tr key={name}><th scope="row">{name}</th><td>{field.state === "source_value" ? String(field.value) : field.state === "source_nonfinite" ? "Source NaN · missing numeric value" : "Source null"}<small className={styles.fieldLocator}>cells.parquet · row {field.locator.rowIndexZeroBased} · {field.locator.column}</small></td></tr>)}</tbody>
        </table>
        {hierarchy && <SourceIdentityHierarchyPanel hierarchy={hierarchy} />}
      </div> : <p role="status">Pinned row unavailable; no preceding row is retained.</p>}
      <details><summary>Original file receipts and remaining pilot inputs</summary>
        <ul className={styles.gates}>{audit.sourceFiles.map((file) => <li key={file.path}><a href={file.url} target="_blank" rel="noreferrer">{file.path.split("/").at(-1)}</a> · {file.bytes.toLocaleString()} bytes<br /><code>{file.sha256}</code></li>)}</ul>
        <ul className={styles.gates}>{audit.remainingGates.map((gate) => <li key={gate.id}><strong>{gate.id.replaceAll("_", " ")}</strong>: {gate.reason}</li>)}</ul>
      </details>
      <p className={styles.notice}>Local source inspection only · 0 viewer geometry. Simplified segmentation polygons do not establish observed membranes, 3D cells, interneuron classification or same-cell morphology. Dataset CC-BY-4.0 and site CC-BY-SA-4.0 declarations remain separate.</p>
    </div>}
  </details>;
}
