# I66 · 来源信息页面的按需索引加载

日期：2026-10-07（America/Toronto）。以I65有限整合checkpoint为前态，继承真正accepted I64原始来源保全时钟；不冒称一次新的全部Root物理重放。

UPG-230有限工程推进。现有Sources与Additional study evidence页面没有对象请求时不下载未使用的Research Explorer索引；明确canonical／legacy／空／错误请求仍要求验证，其余11种collection及旧workspace默认加载行为保留。已有选择移入idle时立即隐藏旧index／record／delta，原AbortController和generation仍拥有迟到结果。完整请求参数及I65无效profile／重复legacy拒绝修复保留。

全程沿用当前新版首页、分级SiteNavigation侧栏、Breadcrumb、独立页面和浅色阅读布局；不改CSS、导航、source loaders、原始数据、package、科学分母、准入或243＋21范围。Provider和Collection属于原runtime成员，whole-runtime byte pins必须合法更新，ordered198及Positions40＋23的membership仍需独立核对。

修改前两个真实页面均已记录manifest与628095B完整索引请求；本地受控HTTP观察只转发到本轮owned3004，正文与encoding保持，响应cache-control设no-store，不能作为whole-App预算或private byte验证的替代。当前应用已写入；最终完整工程、真实页面、请求ledger和末尾scope结果待记录。候选13项测试不是本轮产品验收。

32sources／42sets／387profiles／13rosters／4objects、45named／181selectable／142census／39supplementary及83／243保持。UPG-230不据此完成，完整F01–F20／M0–M4Goal继续active。
