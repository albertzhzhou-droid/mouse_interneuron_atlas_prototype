# Implementation 67 — source-profile view state

Status: candidate implementation under validation; not a complete original-goal acceptance.

The current independent `/explore/cell-types` route retains the upgraded grouped navigation, Breadcrumb, independent route and light reading layout. The selected profile, literal query, source/region/transmitter filters, 0–4 comparisons and distinct baseline are read together from the address. Current exact 387-profile membership across ten namespaces comes from the pinned public index; it grants no canonical identity, same-cell, geometry or private-roster authority.

Malformed, repeated, stale or foreign owned fields fail closed for both the parent active-record request and child dossier/export. Editing a field repairs only that field; explicit profile selection does not silently repair an invalid comparison. An explicit clear control repairs requested comparison/baseline. Zero search matches retain the valid selected dossier. Selection/filter/comparison use history entries; literal search edits replace the current entry. Back/Forward restore the stored baseline rather than manufacturing one from a history transition. Unrelated repeated query fields and the reading fragment are preserved.

Validation in progress. Descriptor tests execute the actual compiled component and real source adapters; controlled history is test-local and is not native-browser proof. The original F01–F20, 243+21 upgrade requirements and M0–M4 remain in scope. Scientific admissions and source gaps are unchanged.
