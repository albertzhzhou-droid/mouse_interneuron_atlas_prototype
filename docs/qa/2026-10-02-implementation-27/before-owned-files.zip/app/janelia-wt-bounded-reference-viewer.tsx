"use client";

import { useEffect, useId, useMemo, useRef, useState } from "react";
import reference from "../data/janelia-wt-bounded-reference-0.1.json";
import { buildJaneliaWtPlaneReceipt, getJaneliaWtNativePlanes, getJaneliaWtSliceMapping, validateJaneliaWtReference, verifyJaneliaWtPayload } from "./janelia-wt-bounded-reference.js";
import styles from "./janelia-wt-bounded-reference-viewer.module.css";

type Chunks = { raw: Uint8Array; nucleus: Uint8Array };
type LoadState = { status: "loading" } | { status: "failed"; message: string } | { status: "ready"; chunks: Chunks };

function SourcePlane({ plane, width, height, labelPlane = false }: { plane: Uint8Array; width: number; height: number; labelPlane?: boolean }) {
  const canvas = useRef<HTMLCanvasElement>(null);
  useEffect(() => {
    const context = canvas.current?.getContext("2d");
    if (!context) return;
    const image = context.createImageData(width, height);
    for (let index = 0; index < plane.length; index += 1) {
      const value = plane[index];
      const color = labelPlane ? (value === 2 ? [230, 177, 77] : value === 255 ? [143, 143, 143] : value === 0 ? [25, 32, 39] : [154, 110, 173]) : [value, value, value];
      image.data.set([...color, 255], index * 4);
    }
    context.putImageData(image, 0, 0);
  }, [plane, width, height, labelPlane]);
  return <div className={styles.plane}>
    <canvas ref={canvas} width={width} height={height} role="img" aria-label={labelPlane ? "Native manual nucleus annotation plane. Amber is instance 2; cell class unknown. The cyan rectangle locates the raw patch." : "Native raw electron microscopy Z plane in source grayscale. X increases right; Y increases downward."} />
    {labelPlane && <svg viewBox="0 0 64 64" aria-hidden="true"><rect x="8" y="48" width="8" height="8" fill="none" stroke="#5ee5f5" strokeWidth="0.6" /></svg>}
  </div>;
}

export default function JaneliaWtBoundedReferenceViewer() {
  const id = useId();
  const [slice, setSlice] = useState(64);
  const [load, setLoad] = useState<LoadState>({ status: "loading" });
  useEffect(() => {
    const controller = new AbortController();
    const acquire = async () => {
      validateJaneliaWtReference(reference);
      const [raw, nucleus] = await Promise.all([reference.raw.payload, reference.nucleus.payload].map(async (descriptor) => {
        const response = await fetch(descriptor.url, { signal: controller.signal });
        if (!response.ok) throw new Error(`Source payload unavailable (${response.status})`);
        return verifyJaneliaWtPayload(new Uint8Array(await response.arrayBuffer()), descriptor);
      }));
      if (!controller.signal.aborted) setLoad({ status: "ready", chunks: { raw, nucleus } });
    };
    acquire().catch((error: unknown) => { if (!controller.signal.aborted) setLoad({ status: "failed", message: error instanceof Error ? error.message : "Source verification failed" }); });
    return () => controller.abort();
  }, []);
  const mapping = useMemo(() => getJaneliaWtSliceMapping(reference, slice), [slice]);
  const planes = useMemo(() => load.status === "ready" ? getJaneliaWtNativePlanes(load.chunks.raw, load.chunks.nucleus, slice) : null, [load, slice]);
  const exportReceipt = () => {
    const url = URL.createObjectURL(new Blob([JSON.stringify(buildJaneliaWtPlaneReceipt(reference, slice), null, 2)], { type: "application/json" }));
    const anchor = document.createElement("a");
    anchor.href = url;
    anchor.download = `jrc_mus-sc-zp104a-native-plane-${slice}.json`;
    anchor.click();
    window.setTimeout(() => URL.revokeObjectURL(url), 0);
  };
  return <section className={styles.panel} aria-labelledby={`${id}-title`} data-testid="janelia-wt-bounded-reference-viewer">
    <div className={styles.heading}><div><small>Janelia WT mouse spinal cord · source reference</small><h3 id={`${id}-title`}>Raw EM + manual nucleus annotation</h3></div><span>Cell class unknown</span></div>
    <p>Explore a small public source patch alongside its coarser manual nucleus annotation. The raw patch lies within manual nucleus instance 2. The displayed annotation is a partial object with no verified neuron type.</p>
    {load.status === "loading" && <p role="status">Loading and verifying the two source chunks…</p>}
    {load.status === "failed" && <p role="alert">{load.message}. No source image is displayed.</p>}
    {planes && <>
      <div className={styles.controls}><label htmlFor={`${id}-slice`}>Raw Z slice <output>{slice + 1} / 128</output><input id={`${id}-slice`} type="range" min="0" max="127" step="1" value={slice} onChange={(event) => setSlice(Number(event.target.value))} /></label><button type="button" onClick={exportReceipt}>Export source receipt</button></div>
      <div className={styles.grid}>
        <figure><SourcePlane plane={planes.raw} width={128} height={128} /><figcaption><strong>Raw EM · 6 nm source samples</strong><span>128 × 128 native pixels · Z sample {(mapping.rawSampleZNanometre / 1000).toFixed(3)} µm</span></figcaption></figure>
        <figure><SourcePlane plane={planes.nucleus} width={64} height={64} labelPlane /><figcaption><strong>Manual nucleus · 96 nm source samples</strong><span>64 × 64 native labels · Z sample {(mapping.labelSampleZNanometre / 1000).toFixed(3)} µm</span></figcaption></figure>
      </div>
      <p className={styles.legend}><span className={styles.amber} />Manual nucleus instance 2 <span className={styles.cyan} />Raw patch location <span className={styles.dark} />Annotation absent</p>
      <p className={styles.notice}>The cyan rectangle locates the raw patch in the source annotation grid. It is a patch outline. All annotation samples in this patch have value 2; a nucleus boundary is not visible within this raw patch. Each displayed annotation plane corresponds to a group of 16 raw Z samples.</p>
    </>}
    <p className={styles.notice}>This source reference stays the same when the atlas cell selection changes. The source’s nominal volume description and array extent differ; biological measurements and atlas registration remain unavailable.</p>
    <details><summary>Source coordinates, reuse and scope</summary><dl className={styles.facts}>
      <div><dt>Exact parent volume</dt><dd>{reference.datasetId}</dd></div><div><dt>Source frame</dt><dd>{reference.sourceFrame}; array axes Z, Y, X</dd></div>
      <div><dt>Raw source affine</dt><dd>Global sample index × 6 nm; translation 0 nm</dd></div><div><dt>Nucleus source affine</dt><dd>Global sample index × 96 nm + 45 nm</dd></div>
      <div><dt>Plane correspondence</dt><dd>Native label sample at the mean coordinate of its 16 raw samples. Images retain native arrays; no interpolation.</dd></div>
      <div><dt>Object scope</dt><dd>{reference.nucleus.objectLabel}; partial annotation; no stable biological cell ID</dd></div><div><dt>Reuse</dt><dd>Both exact Figshare v1 records: CC BY 4.0. Two source chunks decompressed losslessly; label colors and patch rectangle added for display.</dd></div>
      <div><dt>Unresolved extent</dt><dd>Nominal XYZ: 40 × 30 × 75 µm; live array XYZ: 54 × 42 × 76.188 µm</dd></div>
      <div><dt>Evidence scope</dt><dd>0 selected-cell joins; 0 interneuron objects; 0 atlas registrations; 0 biological measurements.</dd></div>
    </dl><p>{reference.sourceRecords.map((record) => <span className={styles.source} key={record.id}><a href={record.url} target="_blank" rel="noreferrer">{record.title}</a><small>{record.citation}</small></span>)}</p></details>
  </section>;
}
