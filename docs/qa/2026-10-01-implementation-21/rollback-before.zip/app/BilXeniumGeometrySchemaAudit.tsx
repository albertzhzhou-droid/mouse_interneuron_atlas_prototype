"use client";

import { useId, useMemo, useState } from "react";
import audit from "../data/bil-xenium-geometry-schema-audit-0.1.json";
import metadata from "../data/bil-xenium-source-metadata-0.1.json";
import { buildBilXeniumAuditedCellHierarchy, validateBilXeniumGeometrySchemaAudit } from "./bil-xenium-geometry-schema-audit.js";
import SourceIdentityHierarchyPanel from "./SourceIdentityHierarchyPanel";
import styles from "./bil-xenium-metadata-explorer.module.css";

export default function BilXeniumGeometrySchemaAudit({ sourceObjectKey, onSelectAcquiredRun }: { sourceObjectKey: string; onSelectAcquiredRun: () => void }) {
  const id = useId();
  const [sampleId, setSampleId] = useState(audit.tables.cells.sampleRows[0].cellId);
  const validation = useMemo(() => {
    try { validateBilXeniumGeometrySchemaAudit(audit, metadata); return null; }
    catch (error) { return error instanceof Error ? error.message : "Source-table audit validation failed"; }
  }, []);
  if (validation) return <p role="alert">{validation}</p>;
  const acquired = sourceObjectKey === audit.sourceObjectKey;
  const cells = audit.tables.cells, boundaries = audit.tables.cellBoundaries, nuclei = audit.tables.nucleusBoundaries;
  const sample = acquired ? cells.sampleRows.find((row) => row.cellId === sampleId) : null;
  const hierarchy = sample ? buildBilXeniumAuditedCellHierarchy(audit, metadata, sample.cellId) : null;

  return <details className={styles.schemaAudit} data-testid="bil-xenium-geometry-schema-audit" data-current-source-key={sourceObjectKey}>
    <summary>Source table audit · {acquired ? "cell and nucleus IDs inspected" : "one other run inspected"}</summary>
    {!acquired ? <div className={styles.auditBody}>
      <p>No original cell or boundary table has been inspected for the selected run. A bounded three-table audit is available for {audit.directoryFolder}.</p>
      <button type="button" className={styles.auditButton} onClick={onSelectAcquiredRun}>Open the inspected run</button>
    </div> : <div className={styles.auditBody} data-testid="bil-xenium-current-schema-audit">
      <p>{cells.rowCount.toLocaleString()} source segmentation rows and three original Parquet tables ({(audit.totalSourceBytes / 1_000_000).toFixed(2)} MB) were inspected. This is one processing ROI; its cells have no verified section, donor or curated type assignment in these inputs.</p>
      <dl className={styles.facts}>
        <div><dt>Cell table IDs / duplicate IDs</dt><dd>{cells.uniqueCellIdCount.toLocaleString()} / {cells.duplicateCellIdCount}</dd></div>
        <div><dt>Cell boundary IDs / vertex rows</dt><dd>{boundaries.uniqueCellIdCount.toLocaleString()} / {boundaries.rowCount.toLocaleString()}</dd></div>
        <div><dt>IDs with nucleus boundaries / nucleus polygons</dt><dd>{nuclei.uniqueCellIdCount.toLocaleString()} / {nuclei.polygonGroupCount.toLocaleString()}</dd></div>
        <div><dt>No detected nucleus / multiple detected nuclei</dt><dd>{cells.nucleusCountDistribution["0"].toLocaleString()} / {nuclei.cellsWithMultiplePolygonGroups}</dd></div>
      </dl>
      <p className={styles.notice}>Join the three files by exact cell_id within this analysis and ROI. {audit.idJoins.crossFileLabelIdDifferentCellCount.toLocaleString()} shared numeric label IDs point to different cells across the two boundary files. Polygon vertices are repeated observations, and multiple nucleus polygons can belong to one cell.</p>
      <p>All cell IDs have a cell boundary; no boundary ID is orphaned. The {audit.idJoins.cellTableIdsWithoutNucleusBoundary.toLocaleString()} IDs without a nucleus boundary match source nucleus_count = 0. Per-cell nucleus counts agree with the number of nucleus polygons, including all 62 multi-nucleus records.</p>
      <p className={styles.notice}>The {audit.methodCrosscheck.tableCounts.nuc_expansion.toLocaleString()} rows with the native label “{audit.methodCrosscheck.distanceEvidence.nativeValue}” explicitly report 5.0 µm. This applies to those rows in this run. The other two methods use source stain segmentation.</p>
      <p>10x describes these coordinate columns in µm. These acquired files contain no explicit unit metadata, section coordinate frame or outline transform; the available platform page is v4.1 and this run is XOA 3.3.0.1. No physical scale or registration is inferred here.</p>
      <div className={styles.controls}>
        <label htmlFor={`${id}-row`}>Inspect a pinned source row
          <select id={`${id}-row`} value={sampleId} onChange={(event) => setSampleId(event.target.value)}>
            {cells.sampleRows.map((row) => <option key={row.cellId} value={row.cellId}>{row.cellId} · row {row.rowIndexZeroBased} · nucleus count {row.fields.nucleus_count.value}</option>)}
          </select>
        </label>
      </div>
      {sample ? <div key={sample.cellId} data-testid="bil-xenium-audited-source-row" data-cell-id={sample.cellId}>
        <p><strong>{sample.cellId}</strong> · cells.parquet · zero-based row {sample.rowIndexZeroBased}. Four pinned examples illustrate source fields; this is not the full cell roster.</p>
        <table className={styles.table} aria-label="Pinned Xenium source row fields"><thead><tr><th>Source column</th><th>Source value</th></tr></thead>
          <tbody>{Object.entries(sample.fields).map(([name, field]) => <tr key={name}><th scope="row">{name}</th><td>{field.state === "source_value" ? String(field.value) : field.state === "source_nonfinite" ? "Source NaN · missing numeric value" : "Source null"}<small className={styles.fieldLocator}>cells.parquet · row {field.locator.rowIndexZeroBased} · {field.locator.column}</small></td></tr>)}</tbody>
        </table>
        {hierarchy && <SourceIdentityHierarchyPanel hierarchy={hierarchy} />}
      </div> : <p role="status">Pinned row unavailable; no preceding row is retained.</p>}
      <details><summary>Original file receipts and remaining pilot inputs</summary>
        <ul className={styles.gates}>{audit.sourceFiles.map((file) => <li key={file.path}><a href={file.url} target="_blank" rel="noreferrer">{file.path.split("/").at(-1)}</a> · {file.bytes.toLocaleString()} bytes<br /><code>{file.sha256}</code></li>)}</ul>
        <ul className={styles.gates}>{audit.remainingGates.map((gate) => <li key={gate.id}><strong>{gate.id.replaceAll("_", " ")}</strong>: {gate.reason}</li>)}</ul>
      </details>
      <p className={styles.notice}>Local source inspection only · 0 viewer geometry. Simplified segmentation polygons do not establish observed membranes, 3D cells, interneuron classification or same-cell morphology. Dataset CC-BY-4.0 and site CC-BY-SA-4.0 declarations remain separate.</p>
    </div>}
  </details>;
}
