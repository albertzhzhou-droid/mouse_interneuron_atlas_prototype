import audit from "../data/bil-xenium-geometry-schema-audit-0.1.json";
import metadata from "../data/bil-xenium-source-metadata-0.1.json";
import { buildBilXeniumRunReceipt } from "./bil-xenium-source-metadata.js";
import type { SourceIdentityHierarchy } from "./source-object-identity.js";
export type BilXeniumGeometrySchemaAudit = typeof audit;
export type BilXeniumMetadata = typeof metadata;
export function validateBilXeniumGeometrySchemaAudit(value: BilXeniumGeometrySchemaAudit, sourceMetadata: BilXeniumMetadata): { sourceObjectKey: string; rawCellRows: number; sourceBytes: number; cellBoundaryVertexRows: number; nucleusBoundaryVertexRows: number; geometryObjects: number };
export function buildBilXeniumCurrentRunReceipt(value: BilXeniumGeometrySchemaAudit, sourceMetadata: BilXeniumMetadata, sourceObjectKey: string): (NonNullable<ReturnType<typeof buildBilXeniumRunReceipt>> & { sourceTableSchemaAudit: BilXeniumGeometrySchemaAudit | null; metadataSnapshotCheckedDate: string }) | null;
export function buildBilXeniumAuditedCellHierarchy(value: BilXeniumGeometrySchemaAudit, sourceMetadata: BilXeniumMetadata, cellId: string): SourceIdentityHierarchy | null;
