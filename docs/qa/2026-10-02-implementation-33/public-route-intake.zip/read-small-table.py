from pathlib import Path
from urllib.request import Request,urlopen
import hashlib,json,datetime
out=Path('/private/tmp/ohri-i33-route-intake');url='https://pmc.ncbi.nlm.nih.gov/articles/PMC13308138/bin/media-3.csv'
req=Request(url,headers={'User-Agent':'OHRI-source-audit/1.0','Accept-Encoding':'identity'})
try:
 with urlopen(req,timeout=30) as r:
  b=r.read(200_001)
  if len(b)>200_000:raise ValueError('table route exceeds bound')
  receipt={'requestedUrl':url,'finalUrl':r.url,'status':r.status,'contentType':r.headers.get('Content-Type'),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'obtainedAt':datetime.datetime.now(datetime.timezone.utc).isoformat()}
 name='media-3-route.response';(out/name).write_bytes(b);(out/(name+'.receipt.json')).write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt));print(b[:600])
except Exception as e: print(type(e).__name__,str(e)); (out/'media-3-route.failure.json').write_text(json.dumps({'url':url,'failure':str(e)},indent=2)+'\n')
