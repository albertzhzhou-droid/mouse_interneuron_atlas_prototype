from pathlib import Path
from urllib.request import Request,urlopen
import hashlib,json,datetime
out=Path('/private/tmp/ohri-i33-route-intake');url='https://www.ncbi.nlm.nih.gov/pmc/utils/oa/oa.fcgi?id=PMC13308138'
with urlopen(Request(url,headers={'User-Agent':'OHRI-source-audit/1.0','Accept-Encoding':'identity'}),timeout=30) as r:
 b=r.read(100_001)
 if len(b)>100_000:raise ValueError('OA response bound exceeded')
 receipt={'requestedUrl':url,'finalUrl':r.url,'status':r.status,'contentType':r.headers.get('Content-Type'),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'obtainedAt':datetime.datetime.now(datetime.timezone.utc).isoformat()}
(out/'oa.response').write_bytes(b);(out/'oa.response.receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt));print(b[:1800])
