from pathlib import Path
from urllib.request import Request,urlopen
import hashlib,json,datetime,gzip
out=Path('/private/tmp/ohri-i33-route-intake');url='https://ftp.ncbi.nlm.nih.gov/geo/series/GSE318nnn/GSE318731/suppl/GSE318731_Multiome_NHASH-IDs.csv.gz'
with urlopen(Request(url,headers={'User-Agent':'OHRI-source-audit/1.0','Accept-Encoding':'identity'}),timeout=30) as r:
 b=r.read(100_001)
 if len(b)>100_000:raise ValueError('hash-map bound exceeded')
 receipt={'requestedUrl':url,'finalUrl':r.url,'status':r.status,'contentType':r.headers.get('Content-Type'),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'obtainedAt':datetime.datetime.now(datetime.timezone.utc).isoformat()}
(out/'GSE318731_Multiome_NHASH-IDs.csv.gz').write_bytes(b)
(out/'GSE318731_Multiome_NHASH-IDs.csv.gz.receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt));print(gzip.decompress(b).decode())
