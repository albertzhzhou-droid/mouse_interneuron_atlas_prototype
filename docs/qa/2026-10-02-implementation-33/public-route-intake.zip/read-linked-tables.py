from pathlib import Path
from urllib.request import Request,urlopen
import hashlib,json,datetime,csv,io
out=Path('/private/tmp/ohri-i33-route-intake')
for n in (1,2,3):
 url=f'https://pmc.ncbi.nlm.nih.gov/articles/instance/13308138/bin/media-{n}.csv'
 with urlopen(Request(url,headers={'User-Agent':'OHRI-source-audit/1.0','Accept-Encoding':'identity'}),timeout=30) as r:
  b=r.read(200_001)
  if len(b)>200_000:raise ValueError('table route exceeds bound')
  receipt={'requestedUrl':url,'finalUrl':r.url,'status':r.status,'contentType':r.headers.get('Content-Type'),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'obtainedAt':datetime.datetime.now(datetime.timezone.utc).isoformat()}
 name=f'media-{n}.csv';(out/name).write_bytes(b);(out/(name+'.receipt.json')).write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt));print(b[:2800])
