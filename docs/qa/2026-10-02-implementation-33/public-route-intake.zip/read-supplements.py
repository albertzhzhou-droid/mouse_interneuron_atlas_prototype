from pathlib import Path
from urllib.request import Request,urlopen
import hashlib,json,datetime,zipfile
out=Path('/private/tmp/ohri-i33-route-intake'); url='https://www.ebi.ac.uk/europepmc/webservices/rest/PMC13308138/supplementaryFiles?includeInlineImages=false'
req=Request(url,headers={'User-Agent':'OHRI-source-audit/1.0','Accept-Encoding':'identity'})
with urlopen(req,timeout=60) as r:
    b=r.read(20_000_001)
    if len(b)>20_000_000: raise ValueError('supplement archive exceeds 20 MB bound')
    receipt={'requestedUrl':url,'finalUrl':r.url,'status':r.status,'contentType':r.headers.get('Content-Type'),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'obtainedAt':datetime.datetime.now(datetime.timezone.utc).isoformat()}
(out/'supplements.zip').write_bytes(b)
(out/'supplements.zip.receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt))
with zipfile.ZipFile(out/'supplements.zip') as z:
    for info in z.infolist():
        print(info.filename,info.file_size,info.compress_size,hex(info.CRC))
        if info.filename.endswith('.csv'):
            if info.file_size>1_000_000: raise ValueError('CSV exceeds 1MB')
            name=Path(info.filename).name
            (out/name).write_bytes(z.read(info))
            print(name,(out/name).read_text()[:3000])
