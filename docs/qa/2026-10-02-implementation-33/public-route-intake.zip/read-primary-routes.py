from pathlib import Path
from urllib.request import Request, urlopen
import hashlib, json, datetime

out=Path('/private/tmp/ohri-i33-route-intake')
routes=[('geo-ftp-list.html','https://ftp.ncbi.nlm.nih.gov/geo/series/GSE318nnn/GSE318731/suppl/'),('paper-analysis-repo.json','https://api.github.com/repos/PoolLab/cano-gomez')]
for name,url in routes:
    req=Request(url,headers={'User-Agent':'OHRI-source-audit/1.0','Accept-Encoding':'identity'})
    try:
        with urlopen(req,timeout=40) as r:
            b=r.read(2_000_001)
            if len(b)>2_000_000: raise ValueError('route response exceeds bounded metadata budget')
            receipt={'requestedUrl':url,'finalUrl':r.url,'status':r.status,'contentType':r.headers.get('Content-Type'),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'obtainedAt':datetime.datetime.now(datetime.timezone.utc).isoformat()}
        (out/name).write_bytes(b); (out/(name+'.receipt.json')).write_text(json.dumps(receipt,indent=2)+'\n')
        print(json.dumps(receipt))
    except Exception as e:
        (out/(name+'.failure.json')).write_text(json.dumps({'url':url,'failure':str(e)},indent=2)+'\n'); print(name,str(e))
