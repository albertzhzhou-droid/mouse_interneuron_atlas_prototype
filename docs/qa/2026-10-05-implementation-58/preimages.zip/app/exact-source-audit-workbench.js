export function sourceAuditSampleKey(sample) {
  return `trevisan-v1:GSE275595:${sample.geoSampleAccession}:source-sample`;
}

export function reconcileSourceAuditSelection(visibleSamples, selectedGsm) {
  return visibleSamples.some((sample) => sample.geoSampleAccession === selectedGsm) ? selectedGsm : null;
}

export function sourceAuditNucleusGate(sample, rights) {
  const reasons = [];
  if (sample.workbookRowCount === 0) reasons.push('No final-workbook rows are available for this sample.');
  if (sample.barcodeMissingRowCount > 0 || sample.barcodeMatchedRowCount !== sample.workbookRowCount) reasons.push('The exact final-workbook to source-native barcode crosswalk is incomplete.');
  if (sample.clusterAssignment == null) reasons.push('No exact per-nucleus cluster assignment is supplied.');
  if (rights.publicAssetPackagingAllowed !== true) reasons.push('File-specific reuse and release scope remain unresolved.');
  return { admitted: reasons.length === 0, reasons };
}

export function filterSourceAuditSamples(samples, query = "", cohort = "all") {
  const terms = query.trim().toLowerCase().split(/\s+/).filter(Boolean);
  return samples.filter((sample) => {
    const atlas = /^P(?:0|14|28|56)[CLT]R[12]$/.test(sample.sampleTitle);
    if (cohort === "atlas" && !atlas) return false;
    if (cohort === "en1" && !/^P0(?:Het|Ko)R[12]$/.test(sample.sampleTitle)) return false;
    if (cohort === "embryonic" && sample.age.developmentalEpoch !== "embryonic") return false;
    const text = [sample.geoSampleAccession, sample.sampleTitle, ...Object.values(sample.characteristics).map((field) => field.value)].join(" ").toLowerCase();
    return terms.every((term) => text.includes(term));
  });
}

export function filterPublicationDiscoveryRecords(records, query = "", status = "all") {
  const terms = query.trim().toLowerCase().split(/\s+/).filter(Boolean);
  return records.filter((record) => {
    if (status !== "all" && record.publicationDiscoveryStatus !== status) return false;
    const text = [record.neuronId, record.nameRaw, record.archiveRaw, record.release, ...record.referencePmidRaw, ...record.referenceDoiRaw].join(" ").toLowerCase();
    return terms.every((term) => text.includes(term));
  });
}

export function makeSourceAuditExport({ kind, audit, records, filter, generatedAt }) {
  if (!['sample_characteristics', 'bounded_publication_discovery'].includes(kind)) throw new Error('Unknown audit export kind');
  const keys = records.map((row) => kind === 'sample_characteristics' ? sourceAuditSampleKey(row) : `NeuroMorpho:${row.release}:${row.neuronId}`);
  if (keys.length !== new Set(keys).size) throw new Error('Duplicate source identity in audit export');
  return {
    format: 'ohri-exact-source-audit-export', version: '0.1.0', kind, auditId: audit.auditId,
    sourceAuditDate: audit.auditDate, generatedAt, filter, rowCount: records.length,
    interpretation: kind === 'sample_characteristics'
      ? 'GEO sample characteristics and final-figure workbook selection counts. Barcode/matrix conflicts prevent runtime nucleus-roster admission; samples and workbook rows are not independent-animal or prevalence counts.'
      : 'Bounded candidate discovery across 1097 frozen morphology records plus 30 independent Todd records and ten pinned taxonomy publications. Unmatched here does not prove absence elsewhere.',
    sourcePayloadsIncluded: false, runtimeRosterAdmission: false, sameCellJoins: 0, geometryObjects: 0, atlasRegistrations: 0,
    records: records.map((record, index) => ({ sourceKey: keys[index], ...record })),
  };
}

function csvCell(value) {
  const text = value == null ? '' : String(value);
  return /[",\r\n]/.test(text) ? `"${text.replaceAll('"', '""')}"` : text;
}

export function sourceAuditCsv(kind, records) {
  const fields = kind === 'sample_characteristics'
    ? ['source_key','gsm','sample_title','source_age','region','replicate','genotype','workbook_selection_rows','native_barcode_columns','matched_rows','missing_rows','admission','source_locator','geometry_objects','same_cell_joins']
    : ['source_key','nmo_id','release','source_name','raw_pmids','raw_dois','bounded_publication_status','reason','object_identity','source_locator','geometry_objects','same_cell_joins'];
  const rows = records.map((row) => kind === 'sample_characteristics'
    ? [sourceAuditSampleKey(row),row.geoSampleAccession,row.sampleTitle,row.age.sourceText,row.characteristics.region.value,row.characteristics.replicate.value,row.characteristics.genotype.value,row.workbookRowCount,row.nativeBarcodeCount,row.barcodeMatchedRowCount,row.barcodeMissingRowCount,row.finalNucleusRosterAdmission,row.characteristics.age.locator,0,0]
    : [`NeuroMorpho:${row.release}:${row.neuronId}`,row.neuronId,row.release,row.nameRaw,JSON.stringify(row.referencePmidRaw),JSON.stringify(row.referenceDoiRaw),row.publicationDiscoveryStatus,row.reason,'not_established',row.locator,0,0]);
  return [fields, ...rows].map((row) => row.map(csvCell).join(',')).join('\r\n') + '\r\n';
}
