import base from "../data/neurolucida-native-contour-admission-catalog-0.3.json" with { type: "json" };
import delta from "../data/neurolucida-native-contour-admission-catalog-0.4.json" with { type: "json" };
import shellContract from "../data/native-contour-derived-soma-surface-0.1.json" with { type: "json" };
import context from "../data/native-contour-source-context-0.1.json" with { type: "json" };
import { validateNativeContourAdmissionCatalog, validateNativeContourGeometry } from "./neurolucida-native-contour-admission.js";
import { validateNativeContourDerivedSomaSurface } from "./native-contour-derived-soma-surface.js";
import { createSourceIdentityHierarchy, SOURCE_IDENTITY_LEVELS } from "./source-object-identity.js";

const catalog = validateNativeContourAdmissionCatalog({ ...delta, baseCatalogSnapshot: base, records: [...base.records, ...delta.addedRecords] });
const proofs = new WeakMap(), shellProofs = new WeakMap();
let sequence = 0;
const check = (ok, message) => { if (!ok) throw new Error(`Native contour source: ${message}`); };
function freeze(value) { if (value && typeof value === "object" && !Object.isFrozen(value)) { Object.values(value).forEach(freeze); Object.freeze(value); } return value; }
freeze(catalog); freeze(context); freeze(shellContract);
const abort = signal => { if (signal?.aborted) throw new DOMException("Native contour request cancelled", "AbortError"); };
export const NATIVE_CONTOUR_SOURCE_IDS = Object.freeze(catalog.records.map(record => record.neuronId));
export function canonicalNativeContourSource(neuronId) {
  const record = catalog.records.find(row => row.neuronId === neuronId);
  check(record?.derivedObject, "the exact record has no admitted native contour geometry");
  const sourceContext = context.records.find(row => row.neuronId === String(neuronId));
  check(sourceContext, "exact source metadata is unavailable");
  return { record, catalogReleaseId: catalog.releaseId, catalogContractId: catalog.contractId, sourceContext,
    shell: neuronId === shellContract.neuronId ? shellContract : null };
}
export function nativeContourSourceHierarchy(neuronId) {
  const source = canonicalNativeContourSource(neuronId), id = String(neuronId);
  const inDelta = delta.addedRecords.some(record => record.neuronId === neuronId);
  const locator = `data/neurolucida-native-contour-admission-catalog-${inDelta ? "0.4" : "0.3"}.json#${inDelta ? "addedRecords" : "records"}/neuronId=${id}`;
  const missing = reason => ({ status: "unknown", id: null, reason });
  const nodes = Object.fromEntries(SOURCE_IDENTITY_LEVELS.map(level => [level, missing(`No exact ${level} ID is retained for this source object.`)]));
  nodes.component = { status: "known", id, locator };
  return createSourceIdentityHierarchy({ sourceId: "native-contours", releaseId: source.catalogReleaseId, namespace: source.catalogContractId,
    objectKind: "native_contour_record", objectId: id, objectLocator: locator, objectLevel: "component", unit: "contours", nodes,
    population: missing("A class label, marker, shared study or root ID is not an exact source-population assignment.") });
}
async function read(file, { fetchImpl = globalThis.fetch, signal, forceReload = false } = {}) {
  abort(signal);
  const path = file.publicPath ?? file.path;
  check(typeof path === "string" && path.startsWith("/data/"), "no exact local source path");
  const cache = forceReload ? "no-store" : "default";
  const response = await fetchImpl(path, { signal, cache });
  abort(signal); check(response.ok, `source request failed (${response.status})`);
  const bytes = await response.arrayBuffer(); abort(signal);
  check(bytes.byteLength === file.bytes, "source byte count changed");
  const digest = await crypto.subtle.digest("SHA-256", bytes); abort(signal);
  const sha256 = Array.from(new Uint8Array(digest), byte => byte.toString(16).padStart(2, "0")).join("");
  check(sha256 === file.sha256, "source SHA-256 mismatch");
  return { value: JSON.parse(new TextDecoder().decode(bytes)), receipt: { path, bytes: bytes.byteLength, sha256,
    verifiedAt: new Date().toISOString(), verificationSequence: ++sequence, requestCacheMode: cache, status: "verified" } };
}
/** Private proof is issued only after exact current bytes and semantic validation. Raw DAT is still a declared receipt. */
export async function readVerifiedNativeContours(neuronId, options = {}) {
  const { record } = canonicalNativeContourSource(neuronId);
  const { value, receipt } = await read(record.derivedObject, options);
  validateNativeContourGeometry(value, record); abort(options.signal);
  freeze(value); proofs.set(value, freeze({ ...receipt, neuronId, assetId: value.assetId, sourceFrame: value.sourceFrame,
    scope: "native_contour_geometry_bytes_only_original_dat_hash_declared" }));
  return value;
}
export async function readVerifiedNativeContourShell(neuronId, contours, options = {}) {
  nativeContourVerification(neuronId, contours);
  const { shell } = canonicalNativeContourSource(neuronId); check(shell, "no derived shell is admitted for this record");
  const { value, receipt } = await read(shell.artifact, options);
  validateNativeContourDerivedSomaSurface(value, contours, { originalDat: shell.sourceOriginalDat, nativeContourGeometry: shell.sourceNativeContourGeometry });
  abort(options.signal); freeze(value); shellProofs.set(value, { contours, receipt: freeze({ ...receipt, neuronId, assetId: value.assetId,
    sourceFrame: value.sourceFrame, scope: "separate_derived_open_shell_bytes_not_observed_membrane" }) });
  return value;
}
export function nativeContourVerification(neuronId, contours, derivedShell = null) {
  const { record, shell } = canonicalNativeContourSource(neuronId), proof = proofs.get(contours);
  check(proof && Object.isFrozen(contours) && proof.neuronId === neuronId && proof.assetId === contours.assetId
    && proof.path === record.derivedObject.path && proof.sha256 === record.derivedObject.sha256 && proof.bytes === record.derivedObject.bytes,
  "this exact immutable contour payload has no private source-byte proof");
  let derived = null;
  if (derivedShell) {
    const verified = shellProofs.get(derivedShell);
    check(shell && verified && verified.contours === contours && Object.isFrozen(derivedShell)
      && verified.receipt.path === shell.artifact.publicPath && verified.receipt.sha256 === shell.artifact.sha256,
    "this exact DER payload has no proof tied to the current OBS contours");
    derived = verified.receipt;
  }
  return freeze({ sourceGeometry: proof, derivedShell: derived });
}
