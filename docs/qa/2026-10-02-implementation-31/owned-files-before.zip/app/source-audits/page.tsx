import BilXeniumMetadataExplorer from "../bil-xenium-metadata-explorer";
import ExactSourceAuditWorkbench from "../ExactSourceAuditWorkbench";
import JaneliaWtBoundedReferenceViewer from "../janelia-wt-bounded-reference-viewer";
import Link from "next/link";
import ComparativeSwcReferenceWorkbench from "../ComparativeSwcReferenceWorkbench";
import AdditionalResearchEvidence from "../AdditionalResearchEvidence";

export default function SourceAuditsPage() {
  return <main style={{ maxWidth: 1180, margin: "0 auto", padding: "1rem" }}>
    <nav aria-label="Research workspaces"><Link href="/">← Atlas</Link>{" · "}<Link href="/objects">Exact structural objects</Link></nav>
    <h1>Source inputs and unresolved mappings</h1>
    <p>These views separate verified source metadata from the geometry and biological identities that the available files can establish.</p>
    <BilXeniumMetadataExplorer />
    <ExactSourceAuditWorkbench />
    <JaneliaWtBoundedReferenceViewer />
    <ComparativeSwcReferenceWorkbench />
    <AdditionalResearchEvidence />
  </main>;
}
