"use client";

import { lazy, Suspense, useCallback, useEffect, useMemo, useState } from "react";
import nativeContourBase from "../data/neurolucida-native-contour-admission-catalog-0.3.json";
import nativeContourDelta from "../data/neurolucida-native-contour-admission-catalog-0.4.json";
import micronsReference from "../data/microns-observed-cell-nucleus-reference-0.1.json";
import bancMorphologyRoute from "../data/banc-v888-in14a018-morphology-route-0.1.json";
import superClemReference from "../data/super-clem-palm-localization-reference-0.1.json";
import microStructFormerReference from "../data/microstructformer-ultrastructure-reference-0.1.json";
import nativeContourDerivedSurface from "../data/native-contour-derived-soma-surface-0.1.json";
import nativeContourCrosswalk from "../data/neurolucida-dat-swc-crosswalk-0.1.json";
import bancCandidateAudit from "../data/banc-v888-candidate-audit-0.1.json";
import nativeContourSourceContext from "../data/native-contour-source-context-0.1.json";
import { version } from "../package.json";
import { buildIndependentSourceObjectIndex, exportIndependentSourceObject, findIndependentSourceObject, listIndependentSourceObjects } from "./independent-source-objects.js";
import { independentSourceReplayExport, independentSourceVisiblePayload, readIndependentSourceLocation, validateIndependentSourceViewReplay, writeIndependentSourceLocation } from "./independent-source-workspace-state.js";
import type { IndependentObject, IndependentPayload, IndependentViewState } from "./independent-source-workspace-types";
import { independentSourceIdentityHierarchy } from "./source-object-identity.js";
import SourceIdentityHierarchyPanel from "./SourceIdentityHierarchyPanel";
import "./independent-source-workspace.css";

const Viewport = lazy(() => import("./IndependentSourceObjectViewport"));
const index = buildIndependentSourceObjectIndex({
  nativeContourCatalog: { ...nativeContourDelta, baseCatalogSnapshot: nativeContourBase, records: [...nativeContourBase.records, ...nativeContourDelta.addedRecords] },
  micronsReference, bancMorphologyRoute, superClemReference, microStructFormerReference, nativeContourDerivedSurface, nativeContourCrosswalk, bancCandidateAudit, nativeContourSourceContext,
});
type Source = { sourceId: string; label?: string; title?: string; sourceName?: string; objectCount?: number; unit?: string; scope?: string; counts: { value: number; unit: string; scopeKey: string; derivedFrom: unknown }[] };
const sources = index.sources as Source[];
type Location = { sourceId: string; key: string | null; query: string; page: number; error: string | null };
type LoadState = { key: string | null; epoch: number; status: "idle" | "loading" | "ready" | "error"; payload: IndependentPayload | null; message: string; loadMilliseconds: number };
const PAGE_SIZE = 25;

function saveJson(value: unknown, filename: string) {
  const url = URL.createObjectURL(new Blob([JSON.stringify(value, null, 2) + "\n"], { type: "application/json" }));
  const link = document.createElement("a"); link.download = filename; link.href = url; document.body.appendChild(link); link.click(); link.remove();
  window.setTimeout(() => URL.revokeObjectURL(url), 1000);
}

export default function IndependentSourceObjectWorkspace() {
  const [location, setLocation] = useState<Location>({ sourceId: sources[0]?.sourceId ?? "", key: null, query: "", page: 0, error: null });
  const [epoch, setEpoch] = useState(0);
  const [load, setLoad] = useState<LoadState>({ key: null, epoch: 0, status: "idle", payload: null, message: "", loadMilliseconds: 0 });
  const [view, setView] = useState<IndependentViewState | null>(null);
  const [restoredView, setRestoredView] = useState<IndependentViewState | null>(null);
  const [importError, setImportError] = useState<string | null>(null);
  const [includeDerivedShell, setIncludeDerivedShell] = useState(false);
  useEffect(() => {
    const restore = () => { setLocation(readIndependentSourceLocation(index, window.location.href)); setEpoch((value) => value + 1); };
    window.addEventListener("popstate", restore);
    const timer = window.setTimeout(restore, 0);
    return () => { window.clearTimeout(timer); window.removeEventListener("popstate", restore); };
  }, []);
  const page = useMemo(() => listIndependentSourceObjects(index, { sourceId: location.sourceId, query: location.query, offset: location.page * PAGE_SIZE, limit: PAGE_SIZE }), [location.sourceId, location.query, location.page]);
  const record = useMemo(() => location.error || !location.key ? null : findIndependentSourceObject(index, location.key) as IndependentObject | null, [location.error, location.key]);
  const payload = (load.epoch === epoch ? independentSourceVisiblePayload(record?.key ?? null, load) : null) as IndependentPayload | null;
  const currentView = record && view?.key === record.key && view.verificationRevision === epoch && payload ? view : null;
  const sourceIdentity = record ? independentSourceIdentityHierarchy(index, record.key) : null;
  const changeLocation = (next: Location) => {
    if (next.key !== location.key) { setEpoch((value) => value + 1); setRestoredView(null); setIncludeDerivedShell(false); }
    setLocation(next);
    window.history.pushState(null, "", writeIndependentSourceLocation(window.location.href, next));
  };
  const updateView = useCallback((next: IndependentViewState) => setView(next), []);
  const invalidateView = useCallback(() => setView(null), []);

  useEffect(() => {
    if (!record) return;
    const controller = new AbortController(); let active = true;
    const started = performance.now();
    // Delayed state publication also preserves a synchronous render-time key gate.
    const timer = window.setTimeout(() => {
      if (active) setLoad({ key: record.key, epoch, status: "loading", payload: null, message: "Verifying source bytes and object identity…", loadMilliseconds: 0 });
    }, 0);
    void import("./independent-source-object-loader.js").then(({ loadIndependentSourceObject }) => loadIndependentSourceObject(record, { signal: controller.signal, includeDerivedShell })).then((next: IndependentPayload) => {
      if (active) setLoad({ key: record.key, epoch, status: "ready", payload: next, message: next.kind === "link_only" ? "Exact source row located; no licensed image asset admitted." : "Exact source object verified.", loadMilliseconds: performance.now() - started });
    }).catch((error: unknown) => {
      if (active && !(error instanceof Error && error.name === "AbortError")) setLoad({ key: record.key, epoch, status: "error", payload: null, message: error instanceof Error ? error.message : "The exact source asset could not be verified.", loadMilliseconds: performance.now() - started });
    });
    return () => { active = false; window.clearTimeout(timer); controller.abort(); };
  }, [record, epoch, includeDerivedShell]);

  const changeQuery = (query: string) => {
    const needle = query.trim().toLocaleLowerCase("en-US");
    const retainsSelection = record && `${record.title} ${record.sourceObjectId} ${record.releaseId}`.toLocaleLowerCase("en-US").includes(needle);
    changeLocation({ ...location, query, page: 0, key: retainsSelection ? location.key : null, error: null });
  };
  return <section className="independent-object-workspace" aria-labelledby="independent-object-workspace-title">
    <header><p>EXACT SOURCE OBJECTS · UPG-251 / 252</p><h3 id="independent-object-workspace-title">Explore a specific structural object</h3><p>Select a source, then an exact record. Each source retains its own object kind, version, counts and missingness.</p></header>
    <div className="independent-object-controls">
      <label htmlFor="independent-object-source">Source<select id="independent-object-source" value={location.sourceId} onChange={(event) => changeLocation({ sourceId: event.target.value, key: null, query: "", page: 0, error: null })}>{!sources.some((source) => source.sourceId === location.sourceId) && <option value={location.sourceId}>Unavailable source</option>}{sources.map((source) => <option key={source.sourceId} value={source.sourceId}>{source.label ?? source.title ?? source.sourceName ?? source.sourceId}</option>)}</select></label>
      <label htmlFor="independent-object-search">Find an object<input id="independent-object-search" type="search" value={location.query} onChange={(event) => changeQuery(event.target.value)} placeholder="Exact ID or source row" /></label>
    </div>
    <label className="independent-object-import">Restore an exported view<input type="file" accept="application/json,.json" onChange={async (event) => {
      const file = event.target.files?.[0]; if (!file) return;
      try {
        const restored = validateIndependentSourceViewReplay(index, JSON.parse(await file.text()), version);
        const next = { sourceId: restored.record.sourceId, key: restored.record.key, query: "", page: 0, error: null };
        setLocation(next); setEpoch((value) => value + 1); setView(null); setRestoredView(restored.view); setIncludeDerivedShell(restored.view.layers.some((layer: { id: string }) => layer.id === "derived-open-shell")); setImportError(null);
        window.history.pushState(null, "", writeIndependentSourceLocation(window.location.href, next));
      } catch (error) { setImportError(error instanceof Error ? error.message : "The view could not be restored."); }
    }} /></label>
    {importError && <p role="alert">{importError}</p>}
    {location.error && <p role="alert">{location.error}</p>}
    <div className="independent-object-layout">
      <div className="independent-object-list">
        <p role="status">{page.total.toLocaleString()} matching entries</p>
        <p className="independent-object-boundary">{sources.find((source) => source.sourceId === location.sourceId)?.counts.map((count) => `${count.value.toLocaleString()} ${count.unit.replaceAll("_", " ")}`).join(" · ")}. Counts retain each source&apos;s own units.</p>
        <ul aria-label="Exact objects in the selected source">{page.records.map((item: IndependentObject) => <li key={item.key}><button type="button" aria-pressed={record?.key === item.key} onClick={() => changeLocation({ ...location, key: item.key, error: null })}><strong>{item.title}</strong><span>{item.objectKind.replaceAll("_", " ")} · {item.sourceObjectId}</span></button></li>)}</ul>
        {!page.total && <p>No matching source object. The search does not create a replacement.</p>}
        <nav aria-label="Source object pages"><button type="button" disabled={location.page === 0} onClick={() => changeLocation({ ...location, page: location.page - 1 })}>Previous</button><span>Page {location.page + 1} / {Math.max(1, Math.ceil(page.total / PAGE_SIZE))}</span><button type="button" disabled={(location.page + 1) * PAGE_SIZE >= page.total} onClick={() => changeLocation({ ...location, page: location.page + 1 })}>Next</button></nav>
      </div>
      <div className="independent-object-detail" data-selected-object={record?.key ?? ""}>
        {!record && <p>Select an exact source object to view its verified geometry and evidence.</p>}
        {record && <>
          <h4>{record.title}</h4><p><code>{record.sourceObjectId}</code> · {record.objectKind.replaceAll("_", " ")}</p><p className="independent-object-release">{record.releaseId}</p>
          <p className="independent-object-boundary">{[record.context.species, record.context.region, record.context.age, record.context.scope].filter((value) => typeof value === "string").join(" · ")}</p>
          {record.components.some((component) => component.id === "derived-open-shell") && <label><input type="checkbox" checked={includeDerivedShell} onChange={(event) => { setIncludeDerivedShell(event.target.checked); setEpoch((value) => value + 1); setRestoredView(null); }} />Load the separately verified DER open shell · interpolation only; no observed membrane or volume</label>}
          {!payload && <p role={load.key === record.key && load.status === "error" ? "alert" : "status"}>{load.key === record.key ? load.message : "Verifying the newly selected object…"}</p>}
          {payload && <Suspense fallback={<p role="status">Preparing the selected object view…</p>}><Viewport key={`${record.key}:${epoch}`} record={record} payload={payload} verificationRevision={epoch} restoredView={restoredView?.key === record.key ? restoredView : null} loadMilliseconds={load.loadMilliseconds} onViewState={updateView} onViewInvalidated={invalidateView} /></Suspense>}
          <dl><div><dt>Source coordinates</dt><dd>{record.coordinateFrame.dimensions}D · {record.coordinateFrame.frame ?? "frame not established"} · {record.coordinateFrame.unit ?? "physical unit not established"}</dd></div>{record.counts.map((count, itemIndex) => <div key={`${count.scopeKey}:${count.unit}:${itemIndex}`}><dt>{count.unit.replaceAll("_", " ")}</dt><dd>{count.value.toLocaleString()} · {count.scopeKey}</dd></div>)}</dl>
          {payload && payload.points.length > 0 && <dl>{payload.points.map((point, pointIndex) => <div key={pointIndex}><dt>Exact source point{point.sourceMatrixColumn != null ? ` · column ${point.sourceMatrixColumn}` : ""}</dt><dd>{point.position.join(", ")}{point.frameIndex != null ? ` · frame index ${point.frameIndex}` : ""} · {record.coordinateFrame.unit ?? "uncalibrated native values"}</dd></div>)}</dl>}
          <div className="independent-object-actions"><a href={record.sourceUrl} target="_blank" rel="noreferrer">Exact source ↗</a><button type="button" onClick={() => saveJson({ ...exportIndependentSourceObject(record, payload?.receipt ?? null), sourceIdentity, applicationVersion: version, status: payload ? payload.receipt.status : load.key === record.key && load.epoch === epoch ? load.status : "loading" }, `source-object-${record.sourceId}.json`)}>Export object evidence</button><button type="button" disabled={!currentView} onClick={() => { if (currentView) saveJson(independentSourceReplayExport(record, payload, currentView, version, index), `source-view-${record.sourceId}.json`); }}>Export current view</button><button type="button" onClick={() => changeLocation({ ...location, key: null, error: null })}>Clear selection</button></div>
          {currentView && <p className="independent-object-timing">Source checks ready in {load.loadMilliseconds.toFixed(0)} ms · view ready in {currentView.renderMilliseconds.toFixed(0)} ms. Measured on this device for this selection; no performance budget is inferred.</p>}
          {sourceIdentity && <SourceIdentityHierarchyPanel hierarchy={sourceIdentity} />}
          <details><summary>Structure availability, exact relationships and file receipts</summary><pre>{JSON.stringify({ coverage: record.structureCoverage, context: record.context, relationships: record.relationships, components: record.components, files: record.files, verification: payload?.receipt ?? null, actualView: currentView }, null, 2)}</pre></details>
        </>}
      </div>
    </div>
  </section>;
}
